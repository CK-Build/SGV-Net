﻿namespace Naked;

public class Class1
{

}
