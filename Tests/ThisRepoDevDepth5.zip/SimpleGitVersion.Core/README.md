
# SimpleGitVersion.Core

Implements [SimpleGitVersion.Abstractions](../SimpleGitVersion.Abstractions) thanks to the excellent [LibGit2Sharp](https://www.nuget.org/packages/LibGit2Sharp).

The [CommitInfo](CommitInfo\CommitInfo.cs) is the main object of this library. The hard work is done by the [TagCollector](TagCollector).

