﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleGitVersion
{
    public class SimpleCommit
    {
        public string Sha { get; set; }

        public string Message { get; set; }

    }
}
